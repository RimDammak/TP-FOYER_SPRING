package com.example.foyer.Services;

public interface IFoyerService {
}
