package com.example.foyer.Repository;

import com.example.foyer.Entities.Foyer;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FoyerRepository extends JpaRepository<Foyer, Long> {
}
