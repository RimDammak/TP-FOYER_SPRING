package com.example.foyer.Services;

public interface IReservationService {
}
