package com.example.foyer.Entities;
import lombok.*;
import jakarta.persistence.*;

public enum TypeChambre {
    Simple, Double , Triple;
}
