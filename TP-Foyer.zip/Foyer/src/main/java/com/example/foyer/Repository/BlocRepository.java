package com.example.foyer.Repository;

import com.example.foyer.Entities.Bloc;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BlocRepository extends JpaRepository <Bloc, Long> {
}
