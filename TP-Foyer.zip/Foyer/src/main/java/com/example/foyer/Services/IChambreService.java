package com.example.foyer.Services;

public interface IChambreService {
}
