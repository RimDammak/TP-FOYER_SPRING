package com.example.foyer.Services;

public class ChambreServiceImpl {
}
