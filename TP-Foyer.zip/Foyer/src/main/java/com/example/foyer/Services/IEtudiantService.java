package com.example.foyer.Services;

public interface IEtudiantService {
}
