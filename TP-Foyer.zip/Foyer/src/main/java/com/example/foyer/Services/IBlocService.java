package com.example.foyer.Services;

import com.example.foyer.Entities.Bloc;

import java.util.List;

public interface IBlocService {
    Bloc addBloc (Bloc bloc);
    List<Bloc> getAllBlocs();
    Bloc getBlocById (long idBloc);
    void deleteBloc(long idBloc);
    Bloc
}
